<?php
session_start();
include '../inc/koneksi.php';
include '../inc/auth.php';
require_role('guru');

$page_title = "Ganti Password Guru";

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_baru = $_POST['password_baru'] ?? '';
    $password_ulang = $_POST['password_ulang'] ?? '';

    // Validasi input
    if (empty($password_baru) || empty($password_ulang)) {
        $error = "Harap isi semua field.";
    } elseif ($password_baru !== $password_ulang) {
        $error = "Password tidak cocok.";
    } else {
        // Update password
        $guru_id = $_SESSION['user_id']; // pastikan session menyimpan user_id guru
        $hash_password = password_hash($password_baru, PASSWORD_DEFAULT);

        $stmt = $koneksi->prepare("UPDATE guru SET password=? WHERE id=?");
        $stmt->bind_param("si", $hash_password, $guru_id);
        if ($stmt->execute()) {
            $success = "Password berhasil diubah.";
        } else {
            $error = "Gagal mengubah password.";
        }
        $stmt->close();
    }
}
?>

<?php include '../inc/header.php'; ?>

<div class="flex justify-center items-center min-h-[70vh]">
    <div class="w-full max-w-md bg-white rounded-2xl shadow-xl border border-blue-200 p-8">
        <h2 class="text-2xl font-bold mb-6 flex items-center gap-2 text-blue-700">
            Ganti Password Guru
        </h2>

        <!-- Tombol Kembali -->
        <a href="index.php" class="inline-block mb-5 px-4 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition">
            Kembali
        </a>

        <?php if (isset($error)): ?>
            <div class="bg-blue-100 text-blue-700 p-3 rounded mb-4 border border-blue-200"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if (isset($success)): ?>
            <div class="bg-blue-100 text-blue-700 p-3 rounded mb-4 border border-blue-200"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form method="POST" class="space-y-5">
            <div>
                <label class="block mb-1 font-semibold text-blue-700" for="password_baru">Password Baru</label>
                <input type="password" name="password_baru" id="password_baru"
                    class="w-full border border-blue-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 transition bg-blue-50 text-blue-900"
                    required autocomplete="new-password">
            </div>
            <div>
                <label class="block mb-1 font-semibold text-blue-700" for="password_ulang">Ulangi Password</label>
                <input type="password" name="password_ulang" id="password_ulang"
                    class="w-full border border-blue-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400 transition bg-blue-50 text-blue-900"
                    required autocomplete="new-password">
            </div>
            <button type="submit"
                class="w-full flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700 transition">
                Simpan Password
            </button>
        </form>
    </div>
</div>

<?php include '../inc/footer.php'; ?>