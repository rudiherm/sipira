<?php
$page_title = "Edit Siswa";
include '../inc/header.php';
include '../inc/koneksi.php';
include '../inc/auth.php';
require_role('admin');

$id = intval($_GET['id'] ?? 0);
if(!$id) header("Location: kelola_siswa.php");

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $nama = $_POST['nama'];
  $kelas = $_POST['kelas'];
  $username = $_POST['username'];
  $sql = $koneksi->prepare("UPDATE siswa SET nama=?,kelas=?,username=? WHERE id=?");
  $sql->bind_param("sssi",$nama,$kelas,$username,$id);
  $sql->execute();
  header("Location: kelola_siswa.php");
  exit;
}

$r = $koneksi->query("SELECT * FROM siswa WHERE id=$id")->fetch_assoc();
?>
<h1 class="text-2xl font-bold mb-4">Edit Siswa</h1>

<form method="post" class="bg-white p-6 rounded shadow space-y-3">
  <input name="nama" value="<?=htmlspecialchars($r['nama'])?>" class="w-full border p-2 rounded" required>
  <input name="kelas" value="<?=htmlspecialchars($r['kelas'])?>" class="w-full border p-2 rounded">
  <input name="username" value="<?=htmlspecialchars($r['username'])?>" class="w-full border p-2 rounded" required>
  <div><button class="px-4 py-2 bg-blue-600 text-white rounded">Simpan</button></div>
</form>

<?php include '../inc/footer.php'; ?>