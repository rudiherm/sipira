<?php
// login_aksi.php
session_start();
include 'inc/koneksi.php';

$username = mysqli_real_escape_string($koneksi, $_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if (!$username || !$password) {
    echo "<script>alert('Masukkan username & password'); window.location='login.php';</script>";
    exit;
}

// check siswa
$q = $koneksi->prepare("SELECT id,username,password,'siswa' as role FROM siswa WHERE username=? UNION SELECT id,username,password,'guru' FROM guru WHERE username=? UNION SELECT id,username,password,'admin' FROM admin WHERE username=? LIMIT 1");
$q->bind_param("sss",$username,$username,$username);
$q->execute();
$res = $q->get_result();

if($res && $row = $res->fetch_assoc()){
    if(password_verify($password, $row['password'])){
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['role'] = $row['role'];
        // redirect
        if($row['role']=='admin') header('Location: admin/index.php');
        if($row['role']=='guru') header('Location: guru/index.php');
        if($row['role']=='siswa') header('Location: siswa/index.php');
        exit;
    } else {
        echo "<script>alert('Password salah'); window.location='login.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('Username tidak ditemukan'); window.location='login.php';</script>";
    exit;
}
?>