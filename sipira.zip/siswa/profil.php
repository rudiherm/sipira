<?php
$page_title = "Profil Saya";
include '../inc/header.php';
include '../inc/koneksi.php';
include '../inc/auth.php';
require_role('siswa');

$id = $_SESSION['user_id'];
$stmt = $koneksi->prepare("SELECT nama, kelas, alamat, motivasi, username, foto FROM siswa WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();
$stmt->close();

$foto_folder = '/uploads/foto_siswa/';
$foto_url = '';

if (!empty($data['foto'])) {
    $foto_path = __DIR__ . '/../' . trim($foto_folder, '/') . '/' . $data['foto'];
    if (file_exists($foto_path)) {
        $foto_url = $foto_folder . $data['foto'];
    }
}
?>

<h1 class="text-4xl font-extrabold mb-10 text-center md:text-left text-gray-900">
    Profil Saya
</h1>

<div class="max-w-4xl mx-auto bg-white rounded-2xl shadow-xl p-10">
    <div class="flex flex-col md:flex-row md:space-x-14 items-center md:items-start">

        <!-- Foto Profil -->
        <div class="mb-8 md:mb-0 flex-shrink-0">
            <?php if ($foto_url): ?>
                <img
                    src="<?= htmlspecialchars($foto_url) ?>"
                    alt="Foto profil <?= htmlspecialchars($data['nama']) ?>"
                    class="w-40 h-40 rounded-full object-cover border-4 border-blue-600 shadow-md"
                    loading="lazy"
                    onerror="this.onerror=null;this.src='/assets/default-user.png';"
                />
            <?php else: ?>
                <div
                    class="w-40 h-40 flex items-center justify-center rounded-full bg-gray-100 text-gray-400 shadow-md border-4 border-blue-600 text-6xl"
                >
                    <i class="fas fa-user"></i>
                </div>
            <?php endif; ?>
        </div>

        <!-- Detail Profil -->
        <div class="flex-1">
            <dl class="grid grid-cols-1 gap-y-8 md:grid-cols-2 md:gap-x-12 text-gray-800">

                <div>
                    <dt class="text-sm font-semibold text-gray-500 uppercase mb-1 tracking-wider">
                        Nama Lengkap
                    </dt>
                    <dd class="text-2xl font-semibold"><?= htmlspecialchars($data['nama']) ?></dd>
                </div>

                <div>
                    <dt class="text-sm font-semibold text-gray-500 uppercase mb-1 tracking-wider">
                        Kelas
                    </dt>
                    <dd class="text-2xl font-semibold"><?= htmlspecialchars($data['kelas']) ?></dd>
                </div>

                <div class="md:col-span-2">
                    <dt class="text-sm font-semibold text-gray-500 uppercase mb-1 tracking-wider">
                        Alamat
                    </dt>
                    <dd
                        class="whitespace-pre-wrap text-gray-700 leading-relaxed text-base border border-gray-200 rounded-lg p-4 bg-gray-50"
                    >
                        <?= nl2br(htmlspecialchars($data['alamat'])) ?>
                    </dd>
                </div>

                <div class="md:col-span-2">
                    <dt class="text-sm font-semibold text-gray-500 uppercase mb-1 tracking-wider">
                        Motivasi
                    </dt>
                    <dd
                        class="whitespace-pre-wrap text-gray-700 leading-relaxed text-base border border-gray-200 rounded-lg p-4 bg-gray-50"
                    >
                        <?= nl2br(htmlspecialchars($data['motivasi'])) ?>
                    </dd>
                </div>
            </dl>

            <div class="mt-12 flex flex-col md:flex-row md:space-x-4 justify-center md:justify-start gap-4">
                <!-- Tombol Kembali -->
                <button
                    onclick="history.back()"
                    class="inline-flex items-center gap-2 px-8 py-3 border border-gray-300 rounded-lg shadow-sm text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-4 focus:ring-gray-300 transition"
                >
                    <i class="fas fa-arrow-left"></i> Kembali
                </button>

                <!-- Tombol Edit Profil -->
                <a
                    href="edit_profil.php"
                    class="inline-flex items-center gap-3 bg-blue-600 hover:bg-blue-700 transition rounded-lg shadow-lg text-white font-semibold px-8 py-3 focus:outline-none focus:ring-4 focus:ring-blue-400"
                >
                    <i class="fas fa-user-edit text-lg"></i> Edit Profil
                </a>
            </div>
        </div>
    </div>
</div>

<?php include '../inc/footer.php'; ?>
