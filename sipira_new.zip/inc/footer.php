<?php
// inc/footer.php
?>
</main>
<footer class="text-center text-sm text-gray-500 py-6">
  &copy; <?=date('Y')?> SMA Negeri 2 Banjar. All Right Reserved.
</footer>
</body>
</html>